<?php
require_once dirname(__FILE__).'/../config.php';
require_once _ROOT_PATH.'/lib/smarty/libs/Smarty.class.php';

use Smarty\Smarty;

function getParams(&$form){
	$form['kwota'] = $_REQUEST['kwota'] ?? null;
	$form['oprocentowanie'] = $_REQUEST['oprocentowanie'] ?? null;
	$form['okres'] = $_REQUEST['okres'] ?? null;
}

function validate(&$form,&$infos,&$msgs){

	if(!(isset($form['kwota']) && isset($form['oprocentowanie']) && isset($form['okres'])))
		return false;

	if($form['kwota'] == "") $msgs[] = 'Podaj kwotę kredytu';
	if($form['oprocentowanie'] == "") $msgs[] = 'Podaj oprocentowanie';
	if($form['okres'] == "") $msgs[] = 'Podaj liczbę miesięcy';

	if(count($msgs) != 0) return false;

	if(!is_numeric($form['kwota'])) $msgs[] = 'Kwota musi być liczbą';
	if(!is_numeric($form['oprocentowanie'])) $msgs[] = 'Oprocentowanie musi być liczbą';
	if(!is_numeric($form['okres'])) $msgs[] = 'Okres musi być liczbą';

	if(count($msgs) != 0) return false;

	return true;
}

function process(&$form,&$infos,&$msgs,&$result){

	$K = floatval($form['kwota']);
	$r = floatval($form['oprocentowanie'])/100/12;
	$n = intval($form['okres']);

	$rata = $K * ($r * pow(1+$r,$n)) / (pow(1+$r,$n)-1);

	$result = round($rata,2);
}

$form = null;
$infos = array();
$msgs = array();
$result = null; 

getParams($form);

if(validate($form,$infos,$msgs)){
	process($form,$infos,$msgs,$result);
}

$smarty = new Smarty();

$smarty->assign('app_url',_APP_URL);
$smarty->assign('root_path',_ROOT_PATH);
$smarty->assign('page_title','Zadanie Smart MN');
$smarty->assign('page_description','Profesjonalne obliczanie rat kredytu');
$smarty->assign('page_header','Szablony Smarty MN');

//pozostałe zmienne niekoniecznie muszą istnieć, dlatego sprawdzamy aby nie otrzymać ostrzeżenia
$smarty->assign('form',$form);
$smarty->assign('result',$result);
$smarty->assign('messages',$msgs);
$smarty->assign('infos',$infos);




// 5. Wywołanie szablonu
$smarty->display(_ROOT_PATH.'/app/calc.html');