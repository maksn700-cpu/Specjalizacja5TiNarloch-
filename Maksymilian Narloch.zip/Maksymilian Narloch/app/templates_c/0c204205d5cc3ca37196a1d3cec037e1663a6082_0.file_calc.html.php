<?php
/* Smarty version 5.4.2, created on 2026-03-11 13:07:41
  from 'file:C:\xampp\htdocs\php_04_uproszczony/app/calc.html' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.2',
  'unifunc' => 'content_69b15b0dc7e859_22963431',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0c204205d5cc3ca37196a1d3cec037e1663a6082' => 
    array (
      0 => 'C:\\xampp\\htdocs\\php_04_uproszczony/app/calc.html',
      1 => 1773230859,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_69b15b0dc7e859_22963431 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'C:\\xampp\\htdocs\\php_04_uproszczony\\app';
$_smarty_tpl->getInheritance()->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->getInheritance()->instanceBlock($_smarty_tpl, 'Block_64997722569b15b0dc4f072_20264035', 'footer');
?>


<?php 
$_smarty_tpl->getInheritance()->instanceBlock($_smarty_tpl, 'Block_182291766169b15b0dc5ead0_01618356', 'content');
$_smarty_tpl->getInheritance()->endChild($_smarty_tpl, "../templates/main.html", $_smarty_current_dir);
}
/* {block 'footer'} */
class Block_64997722569b15b0dc4f072_20264035 extends \Smarty\Runtime\Block
{
public function callBlock(\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'C:\\xampp\\htdocs\\php_04_uproszczony\\app';
?>

Kalkulator rat kredytu
<?php
}
}
/* {/block 'footer'} */
/* {block 'content'} */
class Block_182291766169b15b0dc5ead0_01618356 extends \Smarty\Runtime\Block
{
public function callBlock(\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'C:\\xampp\\htdocs\\php_04_uproszczony\\app';
?>


<h3>Kalkulator rat kredytu</h3>

<form class="pure-form pure-form-stacked" action="<?php echo $_smarty_tpl->getValue('app_url');?>
/php_04_uproszczony/app/calc.php" method="post">
	<fieldset>

		<label for="kwota">Kwota kredytu (zł)</label>
		<input id="kwota" type="text" name="kwota" value="<?php echo $_smarty_tpl->getValue('form')['kwota'];?>
">

		<label for="oprocentowanie">Oprocentowanie roczne (%)</label>
		<input id="oprocentowanie" type="text" name="oprocentowanie" value="<?php echo $_smarty_tpl->getValue('form')['oprocentowanie'];?>
">

		<label for="okres">Liczba miesięcy</label>
		<input id="okres" type="text" name="okres" value="<?php echo $_smarty_tpl->getValue('form')['okres'];?>
">

	</fieldset>

	<button type="submit" class="pure-button pure-button-primary">Oblicz ratę</button>
</form>

<?php if ((null !== ($_smarty_tpl->getValue('result') ?? null))) {?>
<h4>Miesięczna rata: <?php echo $_smarty_tpl->getValue('result');?>
 zł</h4>
<?php }?>

<?php
}
}
/* {/block 'content'} */
}
